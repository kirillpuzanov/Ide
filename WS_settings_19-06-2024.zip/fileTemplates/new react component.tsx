import classNames from 'classnames/bind';
import { useTranslation } from 'react-i18next';
import styles from './${NAME}.module.scss';

const cx = classNames.bind(styles);

type ${NAME}Props = {
   #[[$END$]]#
}

export const ${NAME} = ({}:${NAME}Props) => {
  const { t } = useTranslation();
  return (
    <div className={cx('${NAME}Wrapper')}>
      <p>${NAME}</p>
    </div>
  );
};